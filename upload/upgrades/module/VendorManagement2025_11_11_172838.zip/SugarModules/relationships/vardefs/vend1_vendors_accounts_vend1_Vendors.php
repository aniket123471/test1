<?php
// created: 2025-11-11 17:28:38
$dictionary["vend1_Vendors"]["fields"]["vend1_vendors_accounts"] = array (
  'name' => 'vend1_vendors_accounts',
  'type' => 'link',
  'relationship' => 'vend1_vendors_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_VEND1_VENDORS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
